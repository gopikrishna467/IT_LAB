<?php
include('db.php');
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $branch = $_POST['branch'];
    $phone = $_POST['phone'];
    
    $upload_dir = 'uploads/';
    $photo = '';
    
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $file_name = $_FILES['photo']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $photo = uniqid() . '.' . $file_ext;
        $upload_path = $upload_dir . $photo;
        move_uploaded_file($_FILES['photo']['tmp_name'], $upload_path);
    }
    
    
    $query = "INSERT INTO students (id, name, branch, phone, photo) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("issss", $id, $name, $branch, $phone, $photo);
    
    if ($stmt->execute()) {
        $student_id = $id;

      
        $query = "SELECT id FROM subjects WHERE branch = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $branch);
        $stmt->execute();
        $subjects_result = $stmt->get_result();

        $base_date = new DateTime('2024-06-30');
        $base_time = new DateTime('06:00:00');
        $interval = new DateInterval('P1D'); 
        $time_interval = new DateInterval('PT2H'); 

        
        $insert_exam = $conn->prepare("INSERT INTO exams (student_id, subject_id, exam_date, exam_time) VALUES (?, ?, ?, ?)");
        
        while ($subject = $subjects_result->fetch_assoc()) {
            $subject_id = $subject['id'];
            $exam_date = $base_date->format('Y-m-d');
            $exam_time = $base_time->format('H:i:s');
            $insert_exam->bind_param("iiss", $student_id, $subject_id, $exam_date, $exam_time);
            $insert_exam->execute();

           
            $base_date->add($interval);
            $base_time->add($time_interval);
        }

        $success = "Student registered successfully. <a href='generate_hall_ticket.php?id=$student_id'>Generate Hall Ticket</a>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
    <style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 20px;
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    h2 {
        text-align: center;
        color: #2c3e50;
        margin-bottom: 30px;
        font-size: 2.5em;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
    }
    form {
        max-width: 400px;
        width: 100%;
        margin: 0 auto;
        padding: 30px;
        border: none;
        border-radius: 10px;
        background-color: #fff;
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    input[type="text"], input[type="number"], select, input[type="file"] {
        width: 100%;
        padding: 12px;
        margin: 12px 0;
        border: 1px solid #ddd;
        border-radius: 5px;
        box-sizing: border-box;
        font-size: 16px;
        transition: border-color 0.3s ease;
    }
    input[type="text"]:focus, input[type="number"]:focus, select:focus {
        border-color: #3498db;
        outline: none;
    }
    button {
        width: 100%;
        padding: 12px;
        background-color: #3498db;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 18px;
        transition: background-color 0.3s ease;
    }
    button:hover {
        background-color: #2980b9;
    }
    .error {
        color: #e74c3c;
        margin-bottom: 15px;
        font-size: 14px;
    }
    .success {
        color: #2ecc71;
        margin-bottom: 15px;
        font-size: 16px;
        text-align: center;
    }
    a {
        color: #3498db;
        text-decoration: none;
        transition: color 0.3s ease;
    }
    a:hover {
        color: #2980b9;
    }
    p {
        text-align: center;
        margin-top: 20px;
    }
</style>
</head>
<body>
    <h2>Student Registration</h2>
    <form method="post" action="student_registration.php" enctype="multipart/form-data">
        <?php
        if ($success) {
            echo "<p class='success'>$success</p>";
        }
        ?>
        <input type="number" name="id" placeholder="ID Number" required>
        <input type="text" name="name" placeholder="Name" required>
        <select name="branch" required>
            <option value="">Select Branch</option>
            <option value="Computer Science">Computer Science</option>
            <option value="Electrical Engineering">Electrical Engineering</option>
            <option value="Mechanical Engineering">Mechanical Engineering</option>
            <option value="Civil Engineering">Civil Engineering</option>
        </select>
        <input type="text" name="phone" placeholder="Phone Number" required>
        <input type="file" name="photo" required>
        <button type="submit">Submit</button>
    </form>
    <p><a href="logout.php">Logout</a></p>
</body>
</html>

