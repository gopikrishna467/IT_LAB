<?php
include('db.php');

$student_id = isset($_GET['id']) ? $_GET['id'] : '';

if (!$student_id) {
    die('Student ID is required.');
}

$query = "SELECT * FROM students WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $student = $result->fetch_assoc();
} else {
    $student = [
        'id' => 'N/A',
        'name' => 'Student Not Found',
        'branch' => 'N/A',
        'photo' => 'default.jpg'
    ];
}

$query = "SELECT e.*, s.subject_name 
          FROM exams e 
          JOIN subjects s ON e.subject_id = s.id 
          WHERE e.student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$exams_result = $stmt->get_result();

$exams = [];
while ($row = $exams_result->fetch_assoc()) {
    $exams[] = $row;
}

if (empty($exams)) {
    $branch = $student['branch'];
    $query = "SELECT * FROM subjects WHERE branch = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $branch);
    $stmt->execute();
    $subjects_result = $stmt->get_result();
    
    while ($subject = $subjects_result->fetch_assoc()) {
        $exams[] = [
            'subject_name' => $subject['subject_name'],
            'exam_date' => 'TBA',
            'exam_time' => 'TBA'
        ];
    }
}

if (empty($exams)) {
    $exams[] = [
        'subject_name' => 'No Subjects Found',
        'exam_date' => 'N/A',
        'exam_time' => 'N/A'
    ];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hall Ticket</title>
    <style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 20px;
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    h2 {
        text-align: center;
        color: #2c3e50;
        font-size: 2.5em;
        margin-bottom: 30px;
    }

    .hall-ticket {
        max-width: 800px;
        width: 90%;
        margin: 20px auto;
        padding: 30px;
        border: none;
        border-radius: 15px;
        background-color: #fff;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }

    .student-details {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        margin-bottom: 30px;
    }

    .student-info {
        width: 50%;
        text-align: left;
    }

    .student-info p {
        margin: 10px 0;
        font-size: 18px;
        color: #34495e;
    }

    .student-photo {
        width: 50%;
        text-align: center;
    }

    .student-photo img {
        border-radius: 50%;
        width: 150px;
        height: 150px;
        object-fit: cover;
        border: 5px solid #fff;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    }

    h3 {
        color: #2c3e50;
        text-align: center;
        margin-top: 30px;
        font-size: 1.8em;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }

    th, td {
        padding: 15px;
        text-align: center;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #3498db;
        color: #fff;
        text-transform: uppercase;
        font-weight: bold;
    }

    tr:last-child td {
        border-bottom: none;
    }

    tr:nth-child(even) {
        background-color: #f8f9fa;
    }

    tr:hover {
        background-color: #e8f4f8;
    }

    .buttons {
        display: flex;
        justify-content: center;
        gap: 20px;
        margin-top: 30px;
    }

    button {
        width: 200px;
        padding: 12px;
        background-color: #3498db;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    button:hover {
        background-color: #2980b9;
    }

    button:active {
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    </style>
</head>
<body>
    <h2>Hall Ticket</h2>
    <div class="hall-ticket">
        <div class="student-details">
            <div class="student-info">
                <p><strong>ID:</strong> <?php echo htmlspecialchars($student['id']); ?></p>
                <p><strong>Name:</strong> <?php echo htmlspecialchars($student['name']); ?></p>
                <p><strong>Branch:</strong> <?php echo htmlspecialchars($student['branch']); ?></p>
            </div>
            <div class="student-photo">
                <img src="uploads/<?php echo htmlspecialchars($student['photo']); ?>" alt="Student Photo" onerror="this.src='uploads/default.jpg';">
            </div>
        </div>

        <h3>Exam Details</h3>
        <table>
            <tr>
                <th>Subject</th>
                <th>Exam Date</th>
                <th>Exam Time</th>
            </tr>
            <?php foreach ($exams as $exam) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($exam['subject_name']); ?></td>
                    <td><?php echo htmlspecialchars($exam['exam_date']); ?></td>
                    <td><?php echo htmlspecialchars($exam['exam_time']); ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <div class="buttons">
        <button onclick="window.print()">Print Hall Ticket</button>
        <button onclick="window.close()">Close</button>
    </div>
</body>
</html>

