<?php
include('db.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];


    $query = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $user_id = $user['id'];


        $token = bin2hex(random_bytes(32));


        $token_expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        $update_query = "UPDATE users SET reset_token='$token', reset_token_expiry='$token_expiry' WHERE id='$user_id'";
        $conn->query($update_query);


        $reset_link = "http://example.com/resetpassword.php?token=$token"; 
        $to = $email;
        $subject = 'Password Reset Link';
        $message = "Hello,\n\n";
        $message .= "You have requested to reset your password. Please click the link below to reset your password:\n";
        $message .= "$reset_link\n\n";
        $message .= "If you did not request this, please ignore this email.\n\n";
        $message .= "Thank you,\n";
        $message .= "Your Website Team";
        $headers = 'From: your-email@example.com' . "\r\n" .
                   'Reply-To: your-email@example.com' . "\r\n" .
                   'X-Mailer: PHP/' . phpversion();

        if (mail($to, $subject, $message, $headers)) {
            $success_message = "Password reset link has been sent to your email.";
        } else {
            $error = "Error sending email. Please try again later.";
        }
    } else {
        $error = "Email not found. Please enter a valid email.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa; 
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .container {
            max-width: 400px;
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            text-align: center;
            animation: slideIn 0.5s ease-in-out;
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        form {
            margin-bottom: 20px;
        }

        input[type="email"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff; 
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3; 
        }

        .success-message, .error-message {
            margin-top: 10px;
            color: #155724; 
            background-color: #d4edda; 
            border: 1px solid #c3e6cb;
            padding: 10px;
            border-radius: 5px;
        }

        .error-message {
            color: #721c24; 
            background-color: #f8d7da; 
            border-color: #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Forgot Password</h2>
        <form method="post" action="forgotpassword.php">
            <input type="email" name="email" placeholder="Enter your email" required>
            <button type="submit">Reset Password</button>
            <?php
            if (isset($success_message)) {
                echo "<p class='success-message'>$success_message</p>";
            } elseif (isset($error)) {
                echo "<p class='error-message'>$error</p>";
            }
            ?>
        </form>
        <p><a href="login.php">Back to Login</a></p>
    </div>
</body>
</html>
