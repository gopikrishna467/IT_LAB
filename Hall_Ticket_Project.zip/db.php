<?php
$servername = "localhost:3306//"; 
$username = "gopi";    
$password = "password";   
$dbname = "my_php_app";   


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

