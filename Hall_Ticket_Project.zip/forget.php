<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $query = "UPDATE users SET password='$password' WHERE email='$email'";

    if ($conn->query($query) === TRUE) {
        header('Location: login.php');
        exit;
    } else {
        $error = "Error updating password: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
<style>
    body {
    font-family: Arial, sans-serif;
    margin: 20px;
}

h2 {
    text-align: center;
}

form {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

input[type="text"], input[type="email"], input[type="password"], input[type="file"] {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    width: 100%;
    padding: 10px;
    background-color: #28a745;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #218838;
}

.hall-ticket {
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    text-align: center;
}

.hall-ticket img {
    margin-top: 20px;
}

</style></head>
<body>
    <h2>Forgot Password</h2>
    <form method="post" action="forget.php">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="New Password" required>
        <button type="submit">Reset Password</button>
        <?php if (isset($error)) { echo "<p>$error</p>"; } ?>
    </form>
    <p><a href="login.php">Login</a></p>
</body>
</html>
